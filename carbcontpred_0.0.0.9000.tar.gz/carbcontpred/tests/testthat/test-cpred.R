test_that("cpred-works", {
  expect_equal(cpred(3, 2), 6)
})
