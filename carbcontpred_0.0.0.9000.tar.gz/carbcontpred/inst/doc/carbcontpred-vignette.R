## ----eval = FALSE-------------------------------------------------------------
#  install.packages('carbcontpred', repos = "https://github.com/KangyuSo/my-GEO712-repository/tree/main/carbcontpred")

## -----------------------------------------------------------------------------
library(carbcontpred)

## ----eval = FALSE-------------------------------------------------------------
#  ref_dry <- as.data.frame(apply(data_ref[,-1], MARGIN=2, FUN =continuumRemoval, wav = data_ref$Wavelength))
#  ref_dry <- cbind(Wavelength = data_ref$Wavelength, ref_dry)

## ----eval = FALSE-------------------------------------------------------------
#  start_row <- 350
#  end_row <- 2500
#  ref_dry <- ref_dry[start_row:end_row, 2:ncol(ref_dry)]
#  avg_values <- colMeans(ref_dry, na.rm = TRUE)

## ----eval = FALSE-------------------------------------------------------------
#  ref_dry_avg <- data.frame(
#    "Sample_ID" = colnames(ref_dry),
#    "Reflectance" = avg_values
#  )

## ----eval = FALSE-------------------------------------------------------------
#  ref_dry_avg <- ref_dry_avg %>%
#    left_join(data_met %>% select(Sample_ID, OC), by = "Sample_ID") %>%
#    rename(Organic_Carbon = OC)

## ----echo = FALSE-------------------------------------------------------------
data(ref_dry_avg)
knitr::kable(head(ref_dry_avg))

## ----eval = FALSE-------------------------------------------------------------
#  data <- data.frame(ref_dry_avg)
#  cpred <- function(data, reflectance, carbon, test_size, folds, prediction)

